function TR1indx = GSNN_TR1(TR,TAR,VL,TARV,NurNum,EpcNum,reps,thr)
    net0 = feedforwardnet([NurNum NurNum]);   
    net0.trainParam.epochs = EpcNum;

    indp = find(TAR == 1);
    indn = find(TAR == 0);
    slctnum = round(min(numel(indn)/300,numel(indp)));
    indpV = find(TARV == 1);
    indnV = find(TARV == 0);
    slctnumV = round(min(numel(indnV)/300,numel(indpV)));
    
    r = rand*1000;
    parfor j1 = 1:reps    
        rng(j1+r);
        slct = [indp(randperm(numel(indp),round(slctnum))) ...
            indn(randperm(numel(indn),round(slctnum)))];    
        slct = slct(datasample(1:numel(slct),numel(slct)));
        slct2 = randperm(size(TR,1),3);
        net = configure(net0,TR(slct2,slct),TAR(slct));
        net.divideFcn = 'divideind';
        net.divideParam.trainInd = 1:numel(slct);
        net.divideParam.valInd = [];
        net.divideParam.testInd= [];
        net.trainParam.max_fail = 3;
        net = train(net,TR(slct2,slct),TAR(slct))        
        Net{j1} = net;
        SLCT2{j1} = slct2;
    end
    rng(r);
    
    Dif = zeros(reps,size(TR,1));
    Div = zeros(reps,size(TR,1));
    for j1 = 1:reps
        slct2 = SLCT2{j1};
        net = Net{j1};
        slctV = [indpV(randperm(numel(indpV),round(slctnumV))) ...
            indnV(randperm(numel(indnV),round(slctnumV)))];
        slctV = slctV(datasample(1:numel(slctV),numel(slctV)));
        tr = VL(slct2,slctV);
        [tpr,fpr] = roc(TARV(slctV),net(tr));
        auco = trapz(fpr,tpr);
    
        auc = zeros(1,numel(slct2));
        parfor j2 = 1:numel(slct2)
            trm = tr;
            trm(j2,:) = trm(j2,randperm(size(trm,2)));
            [tpr,fpr] = roc(TARV(slctV),net(trm));
            auc(j2) = trapz(fpr,tpr);
        end
        Dif(j1,slct2) = auco - auc;
        Div(j1,slct2) = 1;
    end
    
    TR1indx = find(sum(Dif)./sum(Div)>thr);
end