function [TR,TAR,VL,TARV,TST,TART,feature_names,nameID,MN,MX]...
    = GSNN_Data_Prep(cmp_lvl)

[file,path] = uigetfile({'*.mat'},...
               'Select dataset','C:\');
load([path file])
nameID = num2cell(1:numel(feature_names))';
rng(100);

% create Pythagorean-tiling mask
tsz = max(size(geo_exclude));
ssz = 13;
tsz = ceil(tsz/ssz)*ssz;
indX = 1:ssz:tsz;
indX = repmat(indX',[1,numel(indX)]);
M = zeros(tsz);
for j = 1:size(indX,1)
    for k = mod(j,2)+1:2:size(indX,2)
        M(indX(j):indX(j)+ssz-1+3,indX(k):indX(k)+ssz-1+3) = 1;
    end
end
M = M(1:size(geo_exclude,1),1:size(geo_exclude,2));
M = M + 1;

% select random samples for validation
tmp = zeros(size(M,1),size(M,2));
tmp(randperm(numel(tmp),round(.35*numel(tmp)))) = 1;
tmp = tmp.*(M==1);
M(tmp==1) = 3;
se = strel('disk',3);
geo_exclude1 = geo_exclude;
geo_exclude1((imdilate(geo_target,se)-geo_target)==1) = 0;
M = M.*geo_exclude1;

display(['Training: ' mat2str(round(100*sum(M(:)==2)/sum(M(:)>0)),4) '%']);
display(['Validation: ' mat2str(round(100*sum(M(:)==3)/sum(M(:)>0)),4) '%']);
display(['Testing: ' mat2str(round(100*sum(M(:)==1)/sum(M(:)>0)),4) '%']);

% study area visualization
figure(1)
vis_elev = squeeze(geo_features(1,:,:));
vis_elev(find(geo_exclude==0)) = NaN;
surf(imresize(vis_elev,.5))
axis off
shading('interp')
colormap(1-spring)
title('Study Area')
view([45 45])
drawnow

% create composite features
if cmp_lvl == 2
    combs = nchoosek(1:size(geo_features,1),2);
end

jj = size(geo_features,1);
if cmp_lvl == 2
    geo_features(size(geo_features,1)+size(combs,1),1,1) = 0;
    for j = 1:size(combs,1)
        jj = jj+1;
        geo_features(jj,:,:) = geo_features(combs(j,1),:,:).*geo_features(combs(j,2),:,:);
    end
    
    for j = 1:size(combs,1)
        feature_names{end+1} = [cell2mat(feature_names(combs(j,1))) ' & ' cell2mat(feature_names(combs(j,2)))];
        nameID{end+1} = [cell2mat(nameID(combs(j,1))) , cell2mat(nameID(combs(j,2)))];
    end
end

% truncate outliers
F = double(geo_features);
clear('geo_features');
T = double(geo_target ~= 0);
for j = 1:size(F,1)
    Fc{j} = min(F(j,:,:),mean(F(j,:))+6*std(F(j,:)));
    Fc{j} = max(F(j,:,:),mean(F(j,:))-6*std(F(j,:)));
end
for j = 1:size(F,1)
    F(j,:,:) = Fc{j};
end

% data partitioning (Training/Validation/Testing)
TR = F(:,find(M==2));
VL = F(:,find(M==3));
TST = F(:,find(M==1));
TAR = T(find(M==2))';
TARV = T(find(M==3))';
TART = T(find(M==1))';

% data normalization
clear('F')
F = TR;
for J = 1:size(F,1)
    MN(J) = min(F(J,:));
    F(J,:) = F(J,:) - MN(J);
    MX(J) = max(F(J,:));
    F(J,:) = F(J,:) / MX(J);
end
TR = F;

clear('F')
F = VL;
for J = 1:size(F,1)
    F(J,:) = F(J,:) - MN(J);
    F(J,:) = F(J,:) / MX(J);
end
VL = F;

clear('F')
F = TST;
for J = 1:size(F,1)
    F(J,:) = F(J,:) - MN(J);
    F(J,:) = F(J,:) / MX(J);
end
TST = F;
end