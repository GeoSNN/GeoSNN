function [Features]...
    = GSNN_Inference_Data_Prep(cmp_lvl,namesR)

[file,path] = uigetfile({'*.mat'},...
               'Select dataset','C:\');
load([path file])
nameID = num2cell(1:numel(feature_names))';
rng(100);


% create composite features
if cmp_lvl == 2
    combs = nchoosek(1:size(geo_features,1),2);
end

jj = size(geo_features,1);
if cmp_lvl == 2
    geo_features(size(geo_features,1)+size(combs,1),1,1) = 0;
    for j = 1:size(combs,1)
        jj = jj+1;
        geo_features(jj,:,:) = geo_features(combs(j,1),:,:).*geo_features(combs(j,2),:,:);
    end
    
    for j = 1:size(combs,1)
        feature_names{end+1} = [cell2mat(feature_names(combs(j,1))) ' & ' cell2mat(feature_names(combs(j,2)))];
        nameID{end+1} = [cell2mat(nameID(combs(j,1))) , cell2mat(nameID(combs(j,2)))];
    end
end

% truncate outliers
F = double(geo_features(:,find(geo_exclude==1)));
clear('geo_features');
for j = 1:size(F,1)
    Fc(j,:) = min(F(j,:),mean(F(j,:))+6*std(F(j,:)));
    Fc(j,:) = max(F(j,:),mean(F(j,:))-6*std(F(j,:)));
end

for j1 = 1:numel(namesR)
    for j2 = 1:numel(feature_names)
        if strcmp(feature_names{j2},namesR{j1}) == 1
            inds(j1) = j2;
        end
    end
end
Features = Fc(inds,:);
end