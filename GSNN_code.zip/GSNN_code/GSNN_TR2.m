function TR2indx = GSNN_TR2(TR,TAR,VL,TARV,NurNum,EpcNum,reps,cmp_lvl)
    net0 = feedforwardnet([NurNum NurNum]); 
    net0.trainParam.epochs = EpcNum;

    indp = find(TAR == 1);
    indn = find(TAR == 0);
    slctnum = round(min(numel(indn)/300,numel(indp)));
    indpV = find(TARV == 1);
    indnV = find(TARV == 0);
    slctnumV = round(min(numel(indnV)/300,numel(indpV)));

    TRo = [];
    VLo = [];
    TR2indx = [];
    j1 = 0;
    down_flag = 0;
    while j1 < size(TR,1) && down_flag == 0
        j1 = j1 + 1;
        for k1 = 1:reps
            slct = [indp(randperm(numel(indp),round(slctnum))) ...
                        indn(randperm(numel(indn),round(slctnum)))];
                    slct = slct(datasample(1:numel(slct),numel(slct)));
            parfor j2 = 1:size(TR,1)  
                if numel(find(TR2indx==j2)) == 0                    
                    tr = [TRo;TR(j2,:)];
                    net = configure(net0,tr(:,slct),TAR(slct));   
                    net.divideFcn = 'divideind';
                    net.divideParam.trainInd = 1:numel(slct);
                    net.divideParam.valInd = [];
                    net.divideParam.testInd= [];  
                    net.trainParam.max_fail = 3;
                    net = train(net,tr(:,slct),TAR(slct));      
                    Net{j2} = net;
                end
            end
            auc = zeros(1,size(TR,1));
            slctV = [indpV(randperm(numel(indpV),round(slctnumV))) ...
                          indnV(randperm(numel(indnV),round(slctnumV)))];
                    slctV = slctV(datasample(1:numel(slctV),numel(slctV)));                     
            parfor j2 = 1:size(TR,1)
                if numel(find(TR2indx==j2)) == 0
                    net = Net{j2};
                    tr = [VLo;VL(j2,:)];
                    [tpr,fpr] = roc(TARV(slctV),net(tr(:,slctV)));
                    auc(j2) = trapz(fpr,tpr);  
                end
            end
            AUCs(k1,:) = auc;
        end
        auc = max(AUCs);
        [vmax,imax] = max(auc);
        TRo = [TRo;TR(imax,:)];
        VLo = [VLo;VL(imax,:)];
        TR2indx(j1) = imax;
        AUC(j1) = vmax;

        [vmax,imax] = max(AUC);

%         if cmp_lvl == 1
%             minf = 3;
%         end
%         if cmp_lvl == 2
%             minf = 10;
%         end
        minf = 2;

        if imax <= j1-5 && j1 >= minf
            down_flag = 1;
        end
    end

    [vmax,imax] = max(AUC);
    imax = max(imax,minf);

    TR2indx = TR2indx(1:imax);
end