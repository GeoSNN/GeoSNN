function [TR,TAR,VL,TARV,TST,TART,names,nameID,MN,MX]...
    = GSNN_Data_Prep(cmp_lvl,region)

load('GSNN_DATA')
nameID = num2cell(1:numel(names))';

if region == 1
    seg = GEO_Seg1;
end
if region == 2
    seg = GEO_Seg2;
end
if region == 3
    seg = GEO_Seg3;
end

% creat region mask
ind = find(seg==1);
s = size(seg);
indx = round(s(1)*(ind/s(1) - floor(ind/s(1))));
indy = ceil(ind/s(1));
seg1 = seg(min(indx):max(indx),min(indy):max(indy));
seg1 = seg1>0;

% create Pythagorean-tiling mask
tsz = max(size(seg1));
ssz = 13;
tsz = ceil(tsz/ssz)*ssz;
indX = 1:ssz:tsz;
indX = repmat(indX',[1,numel(indX)]);
M = zeros(tsz);
for j = 1:size(indX,1)
    for k = mod(j,2)+1:2:size(indX,2)
        M(indX(j):indX(j)+ssz-1+3,indX(k):indX(k)+ssz-1+3) = 1;
    end
end
M = M(1:size(seg1,1),1:size(seg1,2));
M = M + 1;

% select random samples for validation
tmp = zeros(size(M,1),size(M,2));
tmp(randperm(numel(tmp),round(.35*numel(tmp)))) = 1;
tmp = tmp.*(M==1);
M(tmp==1) = 3;
M = M.*seg1;

% isolate features inside region 
geo_feat1 = [GEO_Feat_P(:,min(indx):max(indx),min(indy):max(indy))];
geo_tar1 = GEO_Tar(min(indx):max(indx),min(indy):max(indy));

% study area visualization
figure(1)
vis_elev = squeeze(geo_feat1(1,:,:));
vis_elev(find(seg1==0)) = NaN;
surf(imresize(vis_elev,.5))
axis off
shading('interp')
colormap(1-spring)
title('Study Region')
view([45 45])
drawnow

% create composite features
if cmp_lvl == 2
    combs = nchoosek(1:size(geo_feat1,1),2);
end

jj = size(geo_feat1,1);
if cmp_lvl == 2
    geo_feat1(size(geo_feat1,1)+size(combs,1),1,1) = 0;
    for j = 1:size(combs,1)
        jj = jj+1;
        geo_feat1(jj,:,:) = geo_feat1(combs(j,1),:,:).*geo_feat1(combs(j,2),:,:);
    end
    
    for j = 1:size(combs,1)
        names{end+1} = [cell2mat(names(combs(j,1))) ' & ' cell2mat(names(combs(j,2)))];
        nameID{end+1} = [cell2mat(nameID(combs(j,1))) , cell2mat(nameID(combs(j,2)))];
    end
end

% truncate outliers
F = double(geo_feat1);
clear('geo_feat1');
T = double(geo_tar1 ~= 0);
for j = 1:size(F,1)
    Fc{j} = min(F(j,:,:),mean(F(j,:))+6*std(F(j,:)));
    Fc{j} = max(F(j,:,:),mean(F(j,:))-6*std(F(j,:)));
end
for j = 1:size(F,1)
    F(j,:,:) = Fc{j};
end

% data partitioning (Training/Validation/Testing)
TR = F(:,find(M==2));
VL = F(:,find(M==3));
TST = F(:,find(M==1));
TAR = T(find(M==2))';
TARV = T(find(M==3))';
TART = T(find(M==1))';

% data normalization
clear('F')
F = TR;
for J = 1:size(F,1)
    MN(J) = min(F(J,:));
    F(J,:) = F(J,:) - MN(J);
    MX(J) = max(F(J,:));
    F(J,:) = F(J,:) / MX(J);
end
TR = F;

clear('F')
F = VL;
for J = 1:size(F,1)
    F(J,:) = F(J,:) - MN(J);
    F(J,:) = F(J,:) / MX(J);
end
VL = F;

clear('F')
F = TST;
for J = 1:size(F,1)
    F(J,:) = F(J,:) - MN(J);
    F(J,:) = F(J,:) / MX(J);
end
TST = F;
end