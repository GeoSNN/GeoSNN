function [SNN,ranks] = GSNN_SNN(TR,TAR,VL,TARV,TST,TART,S1,S1V,MN,MX,names,SNN_iterations)
for jj = 1:numel(names)
tmp = names{jj};
ind = find(tmp == ' ');
ind(2:numel(ind)+1) = ind;
ind(1) = 0;
ind(numel(ind)+1) = numel(tmp)+1;
clear('tmp2')
for kk = 1:numel(ind)-1
tmp2{kk} = tmp(ind(kk)+1:ind(kk+1)-1);
end
clear('tmp4')
tmp3 = tmp2{1};
tmp4 = tmp3(1:min(3,numel(tmp3)));
tmp4(end+1) = '.';
for kk = 2:numel(tmp2)
    tmp3 = tmp2{kk};
    tmp4(end+1:end+min(3,numel(tmp3))) = tmp3(1:min(3,numel(tmp3)));
    tmp4(end+1) = '.';
end
names{jj} = tmp4(1:end-1);
end

for j = 1:numel(names)
    mn = min(TR(j,:));
    mx = max(TR(j,:));
    rn = mx-mn;
    G(j,:) = mn:rn/(1e4-1):mx;
end

TRo1 = TR;
TARo1 = TAR;
S1o1 = S1;
trL = numel(TAR);
vlL = numel(TARV);
TR = [TR VL];
TAR = [TAR TARV];
S1 = [S1 S1V];
indp = find(TAR == 1);
indn = find(TAR == 0);
slctnum = round(min(numel(indn)/300,numel(indp)));
indpV = find(TARV == 1);
indnV = find(TARV == 0);
slctnumV = round(min(numel(indnV)/300,numel(indpV)));

TARo = TAR;
TARVo = TARV;
TARTo = TART;
indp = find(TAR == 1);
indn = find(TAR == 0);
nr = 1;
nd = 4;
S1 = S1 - min(S1(:));
taro = S1.^.25;
bl = 0;
df = .1;
tar = taro - bl;
for j4 = 1:9
    tard = dct(tar);
    tard(round(numel(tard)*(df+1.5*(j4-5)/100)):end) = 0;
    tars(j4,:) = idct(tard);
end
tara = TAR;
f = zeros(size(TR,1),size(TR,2));
fV = zeros(size(VL,1),size(VL,2));
fT = zeros(size(TST,1),size(TST,2));
fG = zeros(size(G,1),size(G,2));
Ss = bl*ones(1,size(TR,2));
nn = 2;
ne = 1;
net0 = feedforwardnet([nn nn],'trainlm');
net0.layers{1}.transferFcn = 'radbas';
net0.layers{2}.transferFcn = 'radbas';
net0.layers{3}.transferFcn = 'poslin';
net0.trainParam.epochs = ne;
auc2 = [];
net2 = [];
nets = [];
auc = [];
aucV = [];
aucT = [];
fop = [];
fVop = [];
fTop = [];
fGop = [];
blop = [];
eind2 = [];
track_c = 0;
Track = [];
l1tr = [];
l1 = [];
l1V = [];
l1T = [];
l1G = [];
for k2 = 1:numel(names)
    net1{k2} = [];
    auc1(k2) = -inf;
end
for j = 1:SNN_iterations
    slcto = [indp(randperm(numel(indp),round(slctnum))) ...
                indn(randperm(numel(indn),round(slctnum)))];
    slctoV = [indpV(randperm(numel(indpV),round(slctnumV))) ...
                indnV(randperm(numel(indnV),round(slctnumV)))]+trL;   
    slcto = slcto(datasample(1:numel(slcto),numel(slcto)));
    slctoV = slctoV(datasample(1:numel(slctoV),numel(slctoV)));
    slct = [slcto slctoV];
    for k1 = 1:9       
        parfor k2 = 1:numel(names)       
            tr1 = TR(k2,slct);
            tar1 = tars(k1,slct);  
            net = configure(net0,tr1,tar1);
            net.divideFcn = 'divideind';
            net.divideParam.trainInd = 1:numel(slcto);
            net.divideParam.valInd = numel(slcto)+1:numel(slct);
            net.divideParam.testInd= [];
            net.trainParam.max_fail = 2;
            [net,tr0] = train(net,tr1,tar1);
            ss = [Ss; net(TR(k2,:))]; 
            [tpr,fpr] = roc(TARo,sum(ss));
            auc1(k2) = trapz(fpr,tpr);
            net1{k2} = net;    
        end  
        auc2(k1,:) = auc1;
        net2{k1} = net1;
    end   

    [vs,inds] = max(auc2);   
    auc1 = vs;   
    for j2 = 1:numel(names)
     nets = net2{inds(j2)};
     net1{j2} = nets{j2};
    end   
    [vs,inds] = sort(-auc1);
    eind2 = inds;    

    j2 = 1;
    netb = net1{eind2(j2)};
    f(eind2(j2),:) = f(eind2(j2),:)+netb(TR(eind2(j2),:));
    fV(eind2(j2),:) = fV(eind2(j2),:)+netb(VL(eind2(j2),:));
    fT(eind2(j2),:) = fT(eind2(j2),:)+netb(TST(eind2(j2),:));  
    fG(eind2(j2),:) = fG(eind2(j2),:)+netb(G(eind2(j2),:));


    Ss = sum(f)+bl;    
    [tpr,fpr] = roc(TAR,Ss);
    auc(j) = trapz(fpr,tpr);
    auctr = auc(end);
    tar = taro - Ss;
    
    for j4 = 1:9
        tard = dct(tar);
        tard(round(numel(tard)*(df+1.5*(j4-5)/100)):end) = 0;
        tars(j4,:) = idct(tard);
    end

    tara = TAR - Ss;
    SsV = sum(fV)+bl;
    [tpr,fpr] = roc(TARV,SsV);
    aucV(j) = trapz(fpr,tpr);
    aucval = aucV(end);
    SsT = sum(fT)+bl;
    [tpr,fpr] = roc(TART,SsT);
    aucT(j) = trapz(fpr,tpr);
    auctst = aucT(end);

    hold off
    plot(auc,'b')   
    hold on    
    plot(aucV,'m')
    plot(aucT,'g')
    grid on
    hold off
    title('Training Progress')
    ylabel('AUC')
    xlabel('Iteration')
    leg = legend('Training','Validation','Testing');
    leg.Location = 'southeast';

    drawnow

    fop(j,:,:) = f;
    fVop(j,:,:) = fV;
    fTop(j,:,:) = fT;
    fGop(j,:,:) = fG;
    blop(j) = bl;

if j > 1
    if auc(end) - auc(end-1) <= 0.005
        nn = nn + 1; 
        ne = ne + 1;
        nn = max(min(nn,25),2);
        ne = max(min(ne,25),1);
        net0 = feedforwardnet([nn nn],'trainlm');
        net0.layers{1}.transferFcn = 'radbas';
        net0.layers{2}.transferFcn = 'radbas';
        net0.layers{3}.transferFcn = 'poslin';
        net0.trainParam.epochs = ne;
    end
    if auc(end) - auc(end-1) > 0.005
        nn = nn - 1;
        ne = ne - 1;
        nn = max(min(nn,25),2);
        ne = max(min(ne,25),1);
        net0 = feedforwardnet([nn nn],'trainlm');
        net0.layers{1}.transferFcn = 'radbas';
        net0.layers{2}.transferFcn = 'radbas';
        net0.layers{3}.transferFcn = 'poslin';
        net0.trainParam.epochs = ne;
    end    
end
end

[v,ind] = max(aucV);
f = squeeze(fop(ind,:,:));
fV = squeeze(fVop(ind,:,:));
fT = squeeze(fTop(ind,:,:));
fG = squeeze(fGop(ind,:,:));
bl = blop(ind);


f0 = f;
ss = zeros(1,size(TR,2));
auc1 = zeros(1,size(TR,1));
eind = zeros(1,size(TR,1));
for j1 = 1:size(TR,1)
    parfor j2 = 1:size(TR,1)
        [tpr,fpr] = roc(TAR,sum([ss ; f0(j2,:)]));
        auc1(j2) = trapz(fpr,tpr);
    end
    [vm,indm] = max(auc1);
    eind(j1) = indm;
    ss = ss + f0(indm,:);
    f0(indm,:) = 0;
end

f = f(eind,:);
fV = fV(eind,:);
fT = fT(eind,:);
fG = fG(eind,:);
G = G(eind,:);
names = names(eind);
TR = TR(eind,:);
VL = VL(eind,:);
TST = TST(eind,:);
MN = MN(eind);
MX = MX(eind);
ranks = eind;

f0 = f;
GM = 0;
for j = 1:size(TR,1)
GM(j) = min(f(j,:));
fT(j,:) = fT(j,:) - min(f(j,:));
fG(j,:) = fG(j,:) - min(f(j,:));
fV(j,:) = fV(j,:) - min(f(j,:));
f(j,:) = f(j,:) - min(f(j,:));
end
GM = sum(GM)+bl;
GMx = max(sum(f));
fT = fT / GMx;
fG = fG / GMx;
fV = fV / GMx;
f = f / GMx;

S1b = sum(f)*GMx+GM;
S1bV = sum(fV)*GMx+GM;
S1bT = sum(fT)*GMx+GM;
[tpr,fpr] = roc(TAR,S1b);
AUCtr = trapz(fpr,tpr)
[tpr,fpr] = roc(TARV,S1bV);
AUCval = trapz(fpr,tpr)
[tpr,fpr] = roc(TART,S1bT);
AUCtst = trapz(fpr,tpr)


MNG = 0;
a = zeros(size(f,1),50);b=a;w=a;c= zeros(size(f,1),1);
parfor j = 1:numel(eind)
    cnd = 0;
    cnt = 5;
    net = feedforwardnet([cnt],'trainlm');
    while (cnd == 0) && (cnt <= 50)
        net = feedforwardnet([cnt],'trainlm');
        net.layers{1}.transferFcn = 'radbas';
        net.input.processFcns = {};
        net.output.processFcns = {};
        [net,tr0] = train(net,G(j,:),fG(j,:));
        
        if mean(abs(f(j,:)- net(TR(j,:)))) < 1e-4
            cnd = 1;
        else
            cnt = cnt + 5;
        end
    end
    cnt = min(cnt,50);

    f2(j,:) = net(TR(j,:));
    f2V(j,:) = net(VL(j,:));
    f2T(j,:) = net(TST(j,:));
    
    tmp = zeros(1,50);
    tmp(1:cnt) = net.IW{1};
    a(j,:) = tmp;
    tmp(1:cnt) = net.b{1}';
    b(j,:) = tmp-a(j,:)*MN(j)/MX(j)-a(j,:)*MNG;
    a(j,:) = a(j,:)/MX(j);
    c(j) = net.b{2};
    tmp(1:cnt) = net.LW{2};
    w(j,:) = tmp;
end
% SNN model parameters:
SNN.a = a;
SNN.b = b;
SNN.w = w;
SNN.c = c;

% un-normalize(restore original feature range)
Go = G.*repmat(MX',[1,size(G,2)])+repmat(MN',[1,size(G,2)]);

f2G = squeeze(sum(repmat(w',[1,1,size(Go,2)]).*...
    radbas(repmat(a',[1,1,size(Go,2)]).*...
    permute(repmat(Go,[1,1,size(a,2)]),[3,1,2])+...
    repmat(b',[1,1,size(Go,2)]))))+...
    repmat(c,[1,size(Go,2)]);


S2T = sum(f2T)*GMx+GM;
S2V = sum(f2V)*GMx+GM;
S2 = sum(f2)*GMx+GM;
[tpr,fpr] = roc(TAR,S2);
AUCtr = trapz(fpr,tpr)
[tpr,fpr] = roc(TARV,S2V);
AUCval = trapz(fpr,tpr)
[tpr,fpr] = roc(TART,S2T);
AUCtst = trapz(fpr,tpr)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure('units','normalized','outerposition',[0 0 1 1])
d = ceil(sqrt(numel(eind)));
for j = 1:numel(eind)
    subplot(d,d,j)
    fig = plot(Go(j,:),f2G(j,:),'.');
    tmp = names{j};
    ind = find(tmp == '&');
    clear('tmp2')
    if numel(ind) > 0
    tmp2{1} = tmp(1:ind);
    tmp2{2} = tmp(ind+2:end);
    else
        tmp2 = tmp;
    end
    title(tmp2)  
    mx = max(Go(j,:));
    mn = min(Go(j,:));
    fig.Parent.XLim = [mn mx];
    fig.Parent.XTick = [mn mx];
    fig.Parent.XTickLabel = round([mn mx],1);
    fig.Parent.XTickLabelRotation = 10; 
    fig.Parent.YLim = [0 max(f2G(:))];
    fig.Parent.FontSize = 10;
end