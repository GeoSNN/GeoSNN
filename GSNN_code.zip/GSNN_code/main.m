%% ====================================================================
% Author: Khalid Youssef, PhD (2023)
% Email: khyous@iu.edu
% ====================================================================
% Supplemental code for implementing the SNN optimization pipeline 
% in the paper:
%:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
% K. Youssef, K. Shao, S. Moon & L.-S. Bouchard Landslide susceptibility 
% modeling by interpretable neural network. 
% Communications Earth & Environment 
% https://doi.org/10.1038/s43247-023-00806-5
%:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
% PLEASE ACKNOWLEDGE THE EFFORT THAT WENT INTO DEVELOPMENT 
% BY REFERENCING THE PAPER
% ====================================================================
% ====================================================================
% ====================================================================
% Dependencies:
%
% Requires statistics & machine learning toolbox
% ====================================================================
% Instructions:
%
% Download the processed dataset from: 
% https://dataverse.ucla.edu/dataset.xhtml?persistentId=doi:10.25346/S6/D5QPUA
%
% Run this file for the full pipeline, or call the funcions described
% herein individually.
%
% % Tournament ranking is done in two steps: 
% The function GSNN_TR1 for backwards elimination, 
% and the function GSNN_TR2 for forward selection
% % Teacher MST network training is performed by calling the function:
% GSNN_MST 
% % SNN network training is performed by caslling the function:
% GSNN_SNN
%
% The optimization is to be performed multiple times with different 
% initial conditions, where the model with the highest AUC is selected.
% Just remember to save the SNN model at the end of each optimization.
%
% The examples at the end of this file show how to use the SNN model 
% for inference, and how to plot the additive feature functions.
%
% For questions and comments, please email: land.slide.snn@gmail.com
%% ====================================================================


close all
clear

% Main parameter values  
region = 3; % region options: 1=N-S, 2=NW-SE, 3 = W-E
composite_level = 2; % composite level options: 1, 2
SNN_iterations = 50; % number of SNN training iterations 
% (usually converges within 50 to 100 iterations depending on the region)

% Functions paramater values
NN1 = 5;% number of nurons per layer for Tournament ranking - backwards elimination
NE1 = 50;% number of training epochs for Tournament ranking - backwards elimination
reps1 = 4000;% number of models for Tournament ranking - backwards elimination
thr1 = 0.005;% elimination threshold for Tournament ranking - backwards elimination
NN2 = 8;% number of nurons per layer for Tournament ranking - forward selection
NE2 = 50;% number of training epochs for Tournament ranking - forward selection
reps2 = 3;% number of models per step for Tournament ranking - forward selection

%##########################################################################
%##########################################################################

% Data preparation function
display('Data preparation ...')
[TR,TAR,VL,TARV,TST,TART,names,nameID,MN,MX]...
    = GSNN_Data_Prep(composite_level,region);
display('Data preparation complete')

% Tournament ranking - backwards elimination
display('Tournament ranking step 1/2 ...')
TR1indx = GSNN_TR1(TR,TAR,VL,TARV,NN1,NE1,reps1,thr1);

% select winning features
names = names(TR1indx);% feature names
nameID = nameID(TR1indx);% feature name IDs
TR = TR(TR1indx,:);% Training partition
VL = VL(TR1indx,:);% Validation partition
TST = TST(TR1indx,:);% Testing partition
MX = MX(TR1indx);% feature minimums
MN = MN(TR1indx);% feature maximums
display('Tournament ranking step 1/2 complete')

% Tournament ranking - forward selection
display('Tournament ranking step 2/2 ...')
TR2indx = GSNN_TR2(TR,TAR,VL,TARV,NN2,NE2,reps2,composite_level);

% select winning features
names = names(TR2indx);
nameID = nameID(TR2indx);
TR = TR(TR2indx,:);
VL = VL(TR2indx,:);
TST = TST(TR2indx,:);
MX = MX(TR2indx);
MN = MN(TR2indx);
display('Tournament ranking step 2/2 complete')

% Teacher MST network training
display('Teacher MST training ...')
[res,resV,resT] ...
    = GSNN_MST(TR,TAR,VL,TARV,TST,TART);
S1 = res;
[tpr,fpr] = roc(TAR,res);
auctr = trapz(fpr,tpr)
S1V = resV;
[tprv,fprv] = roc(TARV,resV);
aucval = trapz(fprv,tprv)
[tprt,fprt] = roc(TART,resT);
auctst = trapz(fprt,tprt)
display('Teacher MST training complete')


% SNN network training
display('SNN training ...')
[SNN,ranks] = GSNN_SNN(TR,TAR,VL,TARV,TST,TART,S1,S1V,MN,MX,names,SNN_iterations);
display('SNN training complete')

% #########################################################################

% Inference:

% SNN model parameters
a = SNN.a; b = SNN.b; w = SNN.w; c = SNN.c;
% un-normalize(restore original feature range) and sort by rank
MXR = MX(ranks);
MNR = MN(ranks);
namesR = names(ranks);
TSTR = TST(ranks,:).*repmat(MXR',[1,size(TST,2)])+repmat(MNR',[1,size(TST,2)]);

% SNN single-sample inference, example:
display('SNN single-sample inference example:')
sample = TSTR(:,1);
% individual features contribution
functions = sum(w'.*radbas(a.*repmat(sample,[1,size(a,2)])+b)')'+c;  
display(['------------------'])
display(['------------------'])
for j = 1:numel(namesR)
    display([namesR{j} ': ' mat2str(sample(j))]);
    display(['f(' namesR{j} '): ' mat2str(functions(j))]);
    display(['------------------'])
end
% total sample susceptibility
susceptibility = sum(sum(w'.*radbas(a.*repmat(sample,[1,size(a,2)])+b)')'+c);
display(['------------------'])
display(['susceptibility = ' mat2str(susceptibility)])


% SNN batch inference, example:
Susceptibility = sum(squeeze(sum(repmat(w',[1,1,size(TSTR,2)]).*...
    radbas(repmat(a',[1,1,size(TSTR,2)]).*...
    permute(repmat(TSTR,[1,1,size(a,2)]),[3,1,2])+...
    repmat(b',[1,1,size(TSTR,2)]))))+...
    repmat(c,[1,size(TSTR,2)]));

% SNN batch inference with individual functions, example:
Functions = squeeze(sum(repmat(w',[1,1,size(TSTR,2)]).*...
    radbas(repmat(a',[1,1,size(TSTR,2)]).*...
    permute(repmat(TSTR,[1,1,size(a,2)]),[3,1,2])+...
    repmat(b',[1,1,size(TSTR,2)]))))+...
    repmat(c,[1,size(TSTR,2)]);

% Plot individual feature function from the testing partition, example:
feature_number = 1;% Rank of the feature you want to plot
plot(TSTR(feature_number,:),Functions(feature_number,:),'.')
title(namesR{feature_number})

% Plot individual feature function over the original range:
for j = 1:numel(namesR)
    mn = MNR(j);
    mx = MXR(j);
    rn = mx-mn;
    GR(j,:) = mn:rn/(1e4-1):mx;
end

Functions_GR = squeeze(sum(repmat(w',[1,1,size(GR,2)]).*...
    radbas(repmat(a',[1,1,size(GR,2)]).*...
    permute(repmat(GR,[1,1,size(a,2)]),[3,1,2])+...
    repmat(b',[1,1,size(GR,2)]))))+...
    repmat(c,[1,size(GR,2)]);

figure('units','normalized','outerposition',[0 0 1 1])
d = ceil(sqrt(numel(ranks)));
for j = 1:numel(ranks)
    subplot(d,d,j)
    fig = plot(GR(j,:),Functions_GR(j,:),'.');
    tmp = namesR{j};
    ind = find(tmp == '&');
    clear('tmp2')
    if numel(ind) > 0
    tmp2{1} = tmp(1:ind);
    tmp2{2} = tmp(ind+2:end);
    else
        tmp2 = tmp;
    end
    title(tmp2)  
    mx = max(GR(j,:));
    mn = min(GR(j,:));
    fig.Parent.XLim = [mn mx];
    fig.Parent.XTick = [mn mx];
    fig.Parent.XTickLabel = round([mn mx],1);
    fig.Parent.XTickLabelRotation = 10; 
    fig.Parent.YLim = [0 max(Functions(:))];
    fig.Parent.FontSize = 10;
end