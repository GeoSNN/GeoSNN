function [res,resV,resT] ...
    = GSNN_MST(TR,TAR,VL,TARV,TST,TART)

TRo = TR;
TARo = TAR;
trL = numel(TAR);
vlL = numel(TARV);
indp = find(TAR == 1);
indn = find(TAR == 0);
slctnum = round(min(numel(indn)/300,numel(indp)));
indpV = find(TARV == 1);
indnV = find(TARV == 0);
slctnumV = round(min(numel(indnV)/300,numel(indpV)));
TR = [TR VL];
TAR = [TAR TARV];

reps = 30;
parfor j1 = 1:reps    
    slcto = [indp(randperm(numel(indp),round(slctnum))) ...
                    indn(randperm(numel(indn),round(slctnum)))];
    slctoV = [indpV(randperm(numel(indpV),round(slctnumV))) ...
                indnV(randperm(numel(indnV),round(slctnumV)))]+trL;   
    slcto = slcto(datasample(1:numel(slcto),numel(slcto)));
    slctoV = slctoV(datasample(1:numel(slctoV),numel(slctoV)));
    slct = [slcto slctoV];
    slct2 = [1:size(TR,1)];

    tr = TR(slct2,slct);
    net = feedforwardnet([3],'trainlm');   
    net.layers{1}.transferFcn = 'radbas';
    net.divideFcn = 'divideind';
    net.divideParam.trainInd = 1:numel(slcto);
    net.divideParam.valInd = numel(slcto)+1:numel(slct);
    net.divideParam.testInd= [];
    net.trainParam.max_fail = 2;
    net.trainParam.epochs = 3;
    net = train(net,tr,TAR(slct)); 

    Net1a{j1} = net;
    Slct2a{j1} = slct2;
    S1a(j1,:) = net(TR(slct2,:));
    S1Va(j1,:) = net(VL(slct2,:));
    S1Ta(j1,:) = net(TST(slct2,:));
    S1oa(j1,:) = net(TRo(slct2,:));
end
parfor j1 = 1:reps   
    slcto = 1:trL;
    slctoV = trL+1:trL+vlL;
    taro = TAR(slcto) - S1a(j1,slcto);
    tarod = dct(taro);
    tarod(round(numel(tarod)*.1):end) = 0;
    taro = idct(tarod);
    tarov = TAR(slctoV) - S1a(j1,slctoV);
    tarovd = dct(tarov);
    tarovd(round(numel(tarovd)*.1):end) = 0;
    tarov = idct(tarovd);
    TARb = [taro tarov];

    slcto = [indp(randperm(numel(indp),round(slctnum))) ...
                    indn(randperm(numel(indn),round(slctnum)))];
    slctoV = [indpV(randperm(numel(indpV),round(slctnumV))) ...
                indnV(randperm(numel(indnV),round(slctnumV)))]+trL;   
    slcto = slcto(datasample(1:numel(slcto),numel(slcto)));
    slctoV = slctoV(datasample(1:numel(slctoV),numel(slctoV)));
    slct = [slcto slctoV];
    slct2 = Slct2a{j1};

    tr = [TR(slct2,slct);S1a(j1,slct)];
    net = feedforwardnet([3],'trainlm');
    net.layers{1}.transferFcn = 'radbas';
    net.divideFcn = 'divideind';
    net.divideParam.trainInd = 1:numel(slcto);
    net.divideParam.valInd = numel(slcto)+1:numel(slct);
    net.divideParam.testInd= [];
    net.trainParam.max_fail = 2;
    net.trainParam.epochs = 3;
    net = train(net,tr,TARb(slct)); 

    Net1b{j1} = net;
    Slct2b{j1} = slct2;
    S1b(j1,:) = net([TR(slct2,:);S1a(j1,:)]);
    S1Vb(j1,:) = net([VL(slct2,:);S1Va(j1,:)]);
    S1Tb(j1,:) = net([TST(slct2,:);S1Ta(j1,:)]);
    S1ob(j1,:) = net([TRo(slct2,:);S1oa(j1,:)]);
end
parfor j1 = 1:reps  
    slcto = 1:trL;
    slctoV = trL+1:trL+vlL;
    taro = TAR(slcto) - S1a(j1,slcto) - S1b(j1,slcto);
    tarod = dct(taro);
    tarod(round(numel(tarod)*.1):end) = 0;
    taro = idct(tarod);
    tarov = TAR(slctoV) - S1a(j1,slctoV) - S1b(j1,slctoV);
    tarovd = dct(tarov);
    tarovd(round(numel(tarovd)*.1):end) = 0;
    tarov = idct(tarovd);
    TARc = [taro tarov];

    slcto = [indp(randperm(numel(indp),round(slctnum))) ...
                    indn(randperm(numel(indn),round(slctnum)))];
    slctoV = [indpV(randperm(numel(indpV),round(slctnumV))) ...
                indnV(randperm(numel(indnV),round(slctnumV)))]+trL;   
    slcto = slcto(datasample(1:numel(slcto),numel(slcto)));
    slctoV = slctoV(datasample(1:numel(slctoV),numel(slctoV)));
    slct = [slcto slctoV];
    slct2 = Slct2a{j1};

    tr = [TR(slct2,slct);S1a(j1,slct);S1b(j1,slct)] ;
    net = feedforwardnet([3],'trainlm');
    net.layers{1}.transferFcn = 'radbas';
    net.divideFcn = 'divideind';
    net.divideParam.trainInd = 1:numel(slcto);
    net.divideParam.valInd = numel(slcto)+1:numel(slct);
    net.divideParam.testInd= [];
    net.trainParam.max_fail = 2;
    net.trainParam.epochs = 3; 
    net = train(net,tr,TARc(slct)); 

    Net1c{j1} = net;
    Slct2c{j1} = slct2;
    S1c(j1,:) = net([TR(slct2,:);S1a(j1,:);S1b(j1,:)]);
    S1Vc(j1,:) = net([VL(slct2,:);S1Va(j1,:);S1Vb(j1,:)]);
    S1Tc(j1,:) = net([TST(slct2,:);S1Ta(j1,:);S1Tb(j1,:)]);
    S1oc(j1,:) = net([TRo(slct2,:);S1oa(j1,:);S1ob(j1,:)]);
end
S1 = [S1a;S1b;S1c];
S1V = [S1Va;S1Vb;S1Vc];
S1T = [S1Ta;S1Tb;S1Tc];
S1o = [S1oa;S1ob;S1oc];
res = mean(S1oa+S1ob+S1oc);
resV = mean(S1Va+S1Vb+S1Vc);
resT = mean(S1Ta+S1Tb+S1Tc);
[tpr,fpr] = roc(TARo,res);
auctr(1) = trapz(fpr,tpr);
[tprv,fprv] = roc(TARV,resV);
aucval(1) = trapz(fprv,tprv);
[tprt,fprt] = roc(TART,resT);
auctst(1) = trapz(fprt,tprt);


reps = 90;
for j1 = 1:reps
    slctos{j1} = [indp(randperm(numel(indp),round(slctnum))) ...
                indn(randperm(numel(indn),round(slctnum)))];
    slctosV{j1} = [indpV(randperm(numel(indpV),round(slctnumV))) ...
                indnV(randperm(numel(indnV),round(slctnumV)))]+numel(slctos{j1});
end
parfor j1 = 1:reps      
    slct2 = randperm(size(S1,1),50);
    slcto = slctos{j1};
    slctoV = slctosV{j1};
    slcto = slcto(datasample(1:numel(slcto),numel(slcto)));
    slctoV = slctoV(datasample(1:numel(slctoV),numel(slctoV)));
    slct = [slcto slctoV];
    tr = S1(slct2,slct);
    net = feedforwardnet([3],'trainlm');
    net.layers{1}.transferFcn = 'radbas';
    net.divideFcn = 'divideind';
    net.divideParam.trainInd = 1:numel(slcto);
    net.divideParam.valInd = numel(slcto)+1:numel(slct);
    net.divideParam.testInd= [];
    net.trainParam.max_fail = 2;
    net.trainParam.epochs = 5;
    net = train(net,tr,TAR(slct));       
    Net2{j1} = net;
    S2(j1,:) = net(S1(slct2,:));
    S2V(j1,:) = net(S1V(slct2,:));
    S2T(j1,:) = net(S1T(slct2,:));
    S2o(j1,:) = net(S1o(slct2,:));
end
res = mean(S2o);
resV = mean(S2V);
resT = mean(S2T);
[tpr,fpr] = roc(TARo,res);
auctr(2) = trapz(fpr,tpr);
[tprv,fprv] = roc(TARV,resV);
aucval(2) = trapz(fprv,tprv);
[tprt,fprt] = roc(TART,resT);
auctst(2) = trapz(fprt,tprt);
clear('S1o','S1V','S1T','S1')


reps = 90;
for j1 = 1:reps
    slctos{j1} = [indp(randperm(numel(indp),round(slctnum))) ...
                indn(randperm(numel(indn),round(slctnum)))];
    slctosV{j1} = [indpV(randperm(numel(indpV),round(slctnumV))) ...
                indnV(randperm(numel(indnV),round(slctnumV)))]+numel(slctos{j1});
end
parfor j1 = 1:reps      
    slct2 = randperm(size(S2,1),60);
    slcto = slctos{j1};
    slctoV = slctosV{j1};
    slcto = slcto(datasample(1:numel(slcto),numel(slcto)));
    slctoV = slctoV(datasample(1:numel(slctoV),numel(slctoV)));    
    slct = [slcto slctoV];
    tr = S2(slct2,slct);
    net = feedforwardnet([5],'trainlm');
    net.layers{1}.transferFcn = 'radbas';
    net.divideFcn = 'divideind';
    net.divideParam.trainInd = 1:numel(slcto);
    net.divideParam.valInd = numel(slcto)+1:numel(slct);
    net.divideParam.testInd= [];
    net.trainParam.max_fail = 2;
    net.trainParam.epochs = 5;
    net = train(net,tr,TAR(slct));        
    Net3{j1} = net;
    S3(j1,:) = net(S2(slct2,:));
    S3V(j1,:) = net(S2V(slct2,:));
    S3T(j1,:) = net(S2T(slct2,:));
    S3o(j1,:) = net(S2o(slct2,:));
end
res = mean(S3o);
resV = mean(S3V);
resT = mean(S3T);
[tpr,fpr] = roc(TARo,res);
auctr(3) = trapz(fpr,tpr);
[tprv,fprv] = roc(TARV,resV);
aucval(3) = trapz(fprv,tprv);
[tprt,fprt] = roc(TART,resT);
auctst(3) = trapz(fprt,tprt);
SS{1} = S3;
SSV{1} = S3V;
SST{1} = S3T;
SSo{1} = S3o;
clear('S2o','S2V','S2T','S2')

reps = 90;
for j1 = 1:reps
    slctos{j1} = [indp(randperm(numel(indp),round(slctnum))) ...
                indn(randperm(numel(indn),round(slctnum)))];
    slctosV{j1} = [indpV(randperm(numel(indpV),round(slctnumV))) ...
                indnV(randperm(numel(indnV),round(slctnumV)))]+numel(slctos{j1});
end
parfor j1 = 1:reps      
    slct2 = randperm(size(S3,1),60);
    slcto = slctos{j1};
    slctoV = slctosV{j1};
    slcto = slcto(datasample(1:numel(slcto),numel(slcto)));
    slctoV = slctoV(datasample(1:numel(slctoV),numel(slctoV)));    
    slct = [slcto slctoV];
    tr = S3(slct2,slct);
    net = feedforwardnet([5],'trainlm');
    net.layers{1}.transferFcn = 'radbas';
    net.divideFcn = 'divideind';
    net.divideParam.trainInd = 1:numel(slcto);
    net.divideParam.valInd = numel(slcto)+1:numel(slct);
    net.divideParam.testInd= [];
    net.trainParam.max_fail = 2;
    net.trainParam.epochs = 5;
    net = train(net,tr,TAR(slct));        
    Net4{j1} = net;
    S4(j1,:) = net(S3(slct2,:));
    S4V(j1,:) = net(S3V(slct2,:));
    S4T(j1,:) = net(S3T(slct2,:));
    S4o(j1,:) = net(S3o(slct2,:));
end
res = mean(S4o);
resV = mean(S4V);
resT = mean(S4T);
[tpr,fpr] = roc(TARo,res);
auctr(4) = trapz(fpr,tpr);
[tprv,fprv] = roc(TARV,resV);
aucval(4) = trapz(fprv,tprv);
[tprt,fprt] = roc(TART,resT);
auctst(4) = trapz(fprt,tprt);
SS{2} = S4;
SSV{2} = S4V;
SST{2} = S4T;
SSo{2} = S4o;
clear('S3o','S3V','S3T','S3')

reps = 90;
for j1 = 1:reps
    slctos{j1} = [indp(randperm(numel(indp),round(slctnum))) ...
                indn(randperm(numel(indn),round(slctnum)))];
    slctosV{j1} = [indpV(randperm(numel(indpV),round(slctnumV))) ...
                indnV(randperm(numel(indnV),round(slctnumV)))]+numel(slctos{j1});
end
parfor j1 = 1:reps      
    slct2 = randperm(size(S4,1),60);
    slcto = slctos{j1};
    slctoV = slctosV{j1};
    slcto = slcto(datasample(1:numel(slcto),numel(slcto)));
    slctoV = slctoV(datasample(1:numel(slctoV),numel(slctoV)));    
    slct = [slcto slctoV];
    tr = S4(slct2,slct);
    net = feedforwardnet([5],'trainlm');
    net.layers{1}.transferFcn = 'radbas';
    net.divideFcn = 'divideind';
    net.divideParam.trainInd = 1:numel(slcto);
    net.divideParam.valInd = numel(slcto)+1:numel(slct);
    net.divideParam.testInd= [];
    net.trainParam.max_fail = 2;
    net.trainParam.epochs = 5;
    net = train(net,tr,TAR(slct));        
    Net5{j1} = net;
    S5(j1,:) = net(S4(slct2,:));
    S5V(j1,:) = net(S4V(slct2,:));
    S5T(j1,:) = net(S4T(slct2,:));
    S5o(j1,:) = net(S4o(slct2,:));
end
res = mean(S5o);
resV = mean(S5V);
resT = mean(S5T);
[tpr,fpr] = roc(TARo,res);
auctr(5) = trapz(fpr,tpr);
[tprv,fprv] = roc(TARV,resV);
aucval(5) = trapz(fprv,tprv);
[tprt,fprt] = roc(TART,resT);
auctst(5) = trapz(fprt,tprt);
SS{3} = S5;
SSV{3} = S5V;
SST{3} = S5T;
SSo{3} = S5o;
clear('S4o','S4V','S4T','S4')

ev = (aucval(3:end)./auctr(3:end));
ev = aucval(3:end) - (double(ev < .98)*.025);
[vm,indm] = max(ev);

res = mean(squeeze(SSo{indm}));
resV = mean(squeeze(SSV{indm}));
resT = mean(squeeze(SST{indm}));
[tpr,fpr] = roc(TARo,res);
auctr = trapz(fpr,tpr)
[tprv,fprv] = roc(TARV,resV);
aucval = trapz(fprv,tprv)
[tprt,fprt] = roc(TART,resT);
auctst = trapz(fprt,tprt)
end
